# Lethal Company modpack for the Only Asians meetup
pretty much it

### v1.0.0 

adds these mods
```
BepInEx-BepInExPack
2018-LC_API
bizzlemip-BiggerLobby
anormaltwig-LateCompany
RickArg-Helmet_Cameras
RugbugRedfern-Skinwalkers
stefan750-LCUltrawide
Sligili-More_Emotes
x753-Mimics
Evaisa-HookGenPatcher
Evaisa-LethalLib
MegaPiggy-BuyableShotgunShells
MegaPiggy-BuyableShotgun
Krayken-DynamicDeadline
tinyhoot-ShipLoot
riceinyoursink-BetterTps
Ozone-Runtime_Netcode_Patcher
IAmBatby-LethalLevelLoader
scoopy-Scoopys_Variety_Mod
Backrooms-Backrooms
5Bit-VoiceHUD
CTMods-KarmaForBeingAnnoying
```
### v1.0.1

adds these mods
```
notnotnotswipez-MoreCompany
x753-More_Suits
JunLethalCompany-GamblingMachineAtTheCompany
```

removes these mods
```
2018-LC_API
bizzlemip-BiggerLobby
Backrooms-Backrooms
```