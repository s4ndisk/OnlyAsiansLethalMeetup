# Lethal Company modpack for the Only Asians meetup
pretty much it

### v1.0.0 

adds these mods
```
BepInEx-BepInExPack
2018-LC_API
bizzlemip-BiggerLobby
anormaltwig-LateCompany
RickArg-Helmet_Cameras
RugbugRedfern-Skinwalkers
stefan750-LCUltrawide
Sligili-More_Emotes
x753-Mimics
Evaisa-HookGenPatcher
Evaisa-LethalLib
MegaPiggy-BuyableShotgunShells
MegaPiggy-BuyableShotgun
Krayken-DynamicDeadline
tinyhoot-ShipLoot
riceinyoursink-BetterTps
Ozone-Runtime_Netcode_Patcher
IAmBatby-LethalLevelLoader
scoopy-Scoopys_Variety_Mod
Backrooms-Backrooms
5Bit-VoiceHUD
CTMods-KarmaForBeingAnnoying
```
### v1.0.1

adds these mods
```
notnotnotswipez-MoreCompany
x753-More_Suits
JunLethalCompany-GamblingMachineAtTheCompany
```

removes these mods
```
2018-LC_API
bizzlemip-BiggerLobby
Backrooms-Backrooms
```

### v1.0.2

adds these mods
```
amnsoft-EmployeeAssignments
willis81808-LethalSettings
quackandcheese-MirrorDecor
TheBeeTeam-PersistentPurchases
Ozone-NC_LC_API
Ozone-BepInUtils
Ozone-Cabinet_Item_Storage
Jordo-NeedyCats
axd1x8a-LCAmmoCheck
Zaggy1024-OpenBodyCams
```

removes these mods
```
RickArg-Helmet_Cameras
```

### v1.0.3

adds these mods
```
malco-Lategame_Upgrades-3.1.1
Rune580-LethalCompany_InputUtils-0.6.2
PotatoePet-AdvancedCompany-1.0.148
TheFluff-FairAI-1.3.2
ViViKo-NoSellLimit-1.0.1
FlipMods-TooManyEmotes-1.8.6
jaspercreations-Scopophobia-1.1.1
taffyko-NameplateTweaks-1.0.6
Hexnet111-SuitSaver-1.1.4
Midge-PushCompany-1.2.0
```

removes these mods
```
anormaltwig-LateCompany-1.0.10
Sligili-More_Emotes-1.3.3
CTMods-KarmaForBeingAnnoying-1.1.0
quackandcheese-MirrorDecor-1.3.1
Ozone-Cabinet_Item_Storage-0.0.4
axd1x8a-LCAmmoCheck-1.1.1
```