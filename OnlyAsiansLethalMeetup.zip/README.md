# Lethal Company modpack for the Only Asians meetup
pretty much it

v1.0.0 
adds these mods
```
BepInEx-BepInExPack-5.4.2100
2018-LC_API-3.3.2
bizzlemip-BiggerLobby-2.6.0
anormaltwig-LateCompany-1.0.10
RickArg-Helmet_Cameras-2.1.5
RugbugRedfern-Skinwalkers-3.0.1
stefan750-LCUltrawide-1.1.1
Sligili-More_Emotes-1.3.3
x753-Mimics-2.3.2
Evaisa-HookGenPatcher-0.0.5
Evaisa-LethalLib-0.13.0
MegaPiggy-BuyableShotgunShells-1.0.2
MegaPiggy-BuyableShotgun-1.0.1
Krayken-DynamicDeadline-1.2.2
tinyhoot-ShipLoot-1.0.0
riceinyoursink-BetterTps-1.0.0
Ozone-Runtime_Netcode_Patcher-0.2.5
IAmBatby-LethalLevelLoader-1.0.6
scoopy-Scoopys_Variety_Mod-0.6.5
Backrooms-Backrooms-0.1.3
5Bit-VoiceHUD-1.0.4
CTMods-KarmaForBeingAnnoying-1.1.0
```